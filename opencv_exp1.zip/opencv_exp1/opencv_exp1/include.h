#include <cv.h>
#include <highgui.h>
#include <iostream>
#include <io.h>
#include <direct.h>
#include <string>
#include <vector>
#include <bitset>
#include <iomanip>
#include <ctime>
#include <string.h>
#include <time.h>
#include <opencv.hpp> //opencv 2
#include<cxcore.h>

#define EXCI_WIDTH 32
#define EXCI_HEIGHT 32
#define CLASS_NUM 3
#define PER_HIST_LEN 16
#define HIST_LEN (3*PER_HIST_LEN)

//��Ч�İ׿�����������ֵ
#define MIN_WHITE_PER 0.6

//��Ч�����п�����ֵ
#define VALID_COL_PER 0.65




using namespace std;
using std::vector;
using std::cout;
using std::cin;
using std::endl;
using std::string;

typedef struct imgFile
{
	char* imgAddr;
	IplImage* imgSrc;
	IplImage* imgEdge;
	IplImage*** imgPieces;
	IplImage*** imgEdgePieces;

	int rowCount;
	int colCount;
	int** whiteCol;
	float*** hists;

	int edgeMatConut;

	CvMat* dataMat, *markMat;
	
	
}imgFile;
