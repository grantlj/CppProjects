#include "include.h"

//��ȡĳ�ļ����������ļ���
void getFiles(string path, vector<string>& files)
{
	//�ļ����
	__int64   hFile = 0;
	//�ļ���Ϣ
	struct _finddatai64_t fileinfo;
	string p;
	if ((hFile = _findfirsti64(p.assign(path).append("/*").c_str(), &fileinfo)) != -1)
	{
		do
		{
			//�����Ŀ¼,����֮
			//�������,�����б�
			if ((fileinfo.attrib &  _A_SUBDIR))
			{
				if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
					getFiles(p.assign(path).append("/").append(fileinfo.name), files);
			}
			else
			{
				files.push_back(p.assign(path).append("/").append(fileinfo.name));
			}
		} while (_findnexti64(hFile, &fileinfo) == 0);
		_findclose(hFile);
	}
}

//�������ļ�������ֵ�����ļ��ṹ��ָ��
void loadFiles(vector<string> files, imgFile* imgFiles, int num)
{

	char **pca = new char*[num];
	char **ptmp = pca;
	for (vector<string>::iterator iter = files.begin(); iter != files.end(); ++iter, ++ptmp)
	{
		//Ϊvector<string>��ÿ��Ԫ�ش���һ���ַ�����
		char *p = new char[(*iter).size() + 1];
		//string��c_str()������stringת��Ϊconst char*�ͣ������Ƹ��µ��ַ�����
		strcpy(p, (*iter).c_str());
		//ָ�������ָ������ַ�ָ������pca��
		*ptmp = p;
	}
	//���ַ���������ݴ���imgFile�ṹ��������
	for (int k = 0; k<num; k++)
	{
		(imgFiles + k)->imgAddr = *(pca + k);
	}
}


//��ʼ��
void init(imgFile* img)
{
	img->imgSrc = cvLoadImage(img->imgAddr);
	img->imgEdge = cvCreateImage(cvGetSize(img->imgSrc), IPL_DEPTH_8U, 1);
	cvCanny(img->imgSrc, img->imgEdge, 50, 150, 3);
	img->rowCount = ((img->imgSrc->height) / EXCI_HEIGHT) * 2 - 1;
	img->colCount = ((img->imgSrc->width) / EXCI_WIDTH) * 2 - 1;

	


	img->imgPieces = new IplImage**[img->rowCount];
	for (int i = 0; i < img->rowCount; i++)
	{
		img->imgPieces[i] = new IplImage*[img->colCount];
		for (int j = 0; j < img->colCount; j++)
		{
			img->imgPieces[i][j] = new IplImage[1];
		}
	}

	img->imgEdgePieces = new IplImage**[img->rowCount];
	for (int i = 0; i < img->rowCount; i++)
	{
		img->imgEdgePieces[i] = new IplImage*[img->colCount];
		for (int j = 0; j < img->colCount; j++)
		{
			img->imgEdgePieces[i][j] = new IplImage[1];
		}
	}

	img->hists = new float**[img->rowCount];
	for (int i = 0; i < img->rowCount; i++)
	{
		img->hists[i] = new float*[img->colCount];
		for (int j = 0; j < img->colCount; j++)
		{
			img->hists[i][j] = new float[HIST_LEN];
		}
	}


	img->whiteCol = new int*[img->rowCount];
	for (int i = 0; i < img->colCount; i++)
	{
		img->whiteCol[i] = new int[img->colCount];
	}
}

//��ͼƬת��������
void transToHist(IplImage * src, float* vec)
{
	//debug
	cout << "9999999" << endl;
	IplImage* r_plane = cvCreateImage(cvGetSize(src), 8, 1);
	IplImage* g_plane = cvCreateImage(cvGetSize(src), 8, 1);
	IplImage* b_plane = cvCreateImage(cvGetSize(src), 8, 1);
	//IplImage* planes[] = {h_plane,s_plane};   
	//!!!!!!!!!!!!!!---------!!!!!!!!!!! ѡ���ǲ���RGB
	IplImage* hsv = cvCreateImage(cvGetSize(src), 8, 3);
	cvCvtColor(src, hsv, CV_BGR2HSV);
	cvCvtPixToPlane(hsv, b_plane, g_plane, r_plane, 0);//openCV�����һ������,���Կ���cvSplit�����ĺ�:#define cvCvtPixToPlane cvSplit    
	//ע��˳��ΪBGR,OpenCV�в�����Windows��Load�Ļ�������ͷȡ�õĶ���BGR˳�����е�   

	//����ֱ��ͼ     
	int hist_size = PER_HIST_LEN;//����
	int hist_height = 100;
	float range[] = { 0, 255 };
	float* ranges[] = { range };
	CvHistogram* r_hist = cvCreateHist(1, &hist_size, CV_HIST_ARRAY, ranges, 1);
	CvHistogram* g_hist = cvCreateHist(1, &hist_size, CV_HIST_ARRAY, ranges, 1);
	CvHistogram* b_hist = cvCreateHist(1, &hist_size, CV_HIST_ARRAY, ranges, 1);

	cvCalcHist(&r_plane, r_hist, 0, 0);
	cvNormalizeHist(r_hist, 1.0);
	cvCalcHist(&g_plane, g_hist, 0, 0);
	cvNormalizeHist(g_hist, 1.0);
	cvCalcHist(&b_plane, b_hist, 0, 0);
	cvNormalizeHist(b_hist, 1.0);


	int k = 0;

	for (int i = 0; i<hist_size; i++)
	{
		float bin_val = cvQueryHistValue_1D(r_hist, i);
		vec[k++] = bin_val;
	}
	for (int i = 0; i<hist_size; i++)
	{
		float bin_val = cvQueryHistValue_1D(g_hist, i);
		vec[k++] = bin_val;
	}
	for (int i = 0; i<hist_size; i++)
	{
		float bin_val = cvQueryHistValue_1D(b_hist, i);
		vec[k++] = bin_val;
	}

	cvReleaseImage(&r_plane);
	cvReleaseImage(&r_plane);
	cvReleaseImage(&b_plane);

}


//ͳ��С�׵㣺��
int getWhiteCount(IplImage* pCannyImg)
{
	long int s = 0;
	for (int i = 0; i < pCannyImg->height; i++)
	for (int j = 0; j < pCannyImg->width; j++)
	{
		CvScalar t1 = cvGet2D(pCannyImg, i, j);
		if (t1.val[0] != 0)
		{
			s++;
			break;
		}
	}
	return s;
}


//���ĺ���
void doCore(imgFile* img)
{
	
	CvRect rect = cvRect(0, 0, EXCI_WIDTH, EXCI_HEIGHT);
	for (int i = 0; i < img->rowCount; i++)
	{
		for (int j = 0; j < img->colCount; j++)
		{
			img->imgPieces[i][j]=cvCreateImage(cvSize(EXCI_WIDTH, EXCI_HEIGHT), img->imgSrc->depth, img->imgSrc->nChannels);
			img->imgEdgePieces[i][j] = cvCreateImage(cvSize(EXCI_WIDTH, EXCI_HEIGHT), img->imgEdge->depth, img->imgEdge->nChannels);
			
			rect.x = j*(EXCI_WIDTH / 2);
			rect.y = i*(EXCI_HEIGHT / 2);

			cvSetImageROI(img->imgSrc, rect);
			cvSetImageROI(img->imgEdge, rect);

			cvCopyImage(img->imgSrc, img->imgPieces[i][j]);
			cvCopyImage(img->imgEdge, img->imgEdgePieces[i][j]);

			transToHist(img->imgPieces[i][j], img->hists[i][j]);
			if (getWhiteCount(img->imgEdgePieces[i][j])>EXCI_HEIGHT*MIN_WHITE_PER)
			{
				img->whiteCol[i][j] = 1;
			}
			else img->whiteCol[i][j] = 0;

			cvResetImageROI(img->imgSrc);
			cvResetImageROI(img->imgEdge);
		}

	}
	
}

void polishWhiteMat(imgFile* img)
{
	int* validColFlag = new int[img->colCount];
	//������Ч��
	for (int i = 0; i < img->colCount; i++)
	{
		validColFlag[i] = 0;
		int s = 0;
		for (int j = 0; j < img->colCount; j++)
		{
			if (img->whiteCol[i][j] == 1)
				s++;
		}
		if (((float)s) / img->rowCount>VALID_COL_PER)
			validColFlag[i] = 1;
	}

	int startCol = 0;
	int endCol = img->colCount - 1;

	for (int i = 0; i < img->colCount - 3; i++)
	{
		//Ĭ��3�С���������
		if (validColFlag[i] == 1 && validColFlag[i + 1] == 1 && validColFlag[i + 2] == 1)
		{
			startCol = i;
			break;
		}
	}

	for (int i = img->colCount - 1; i >= 2; i--)
	{
		//Ĭ��3�С���������
		if (validColFlag[i] == 1 && validColFlag[i - 1] == 1 && validColFlag[i - 2] == 1)
		{
			endCol = i;
			break;
		}
	}
	delete[] validColFlag;

	for (int i = 0; i < startCol - 2; i++)
	{
		for (int j = 0; j < img->rowCount; j++)
		{
			img->whiteCol[j][i] = 0;
		}
	}

	for (int i = endCol + 2; i < img->colCount; i++)
	{
		for (int j = 0; j < img->rowCount; j++)
		{
			img->whiteCol[j][i] = 0;
		}
	}

	img->edgeMatConut = 0;
	for (int i = 0; i < img->rowCount; i++)
	{
		for (int j = 0; j < img->colCount;j++)
		if (img->whiteCol[i][j] == 1)
			img->edgeMatConut++;

	}
}

void cluster(struct imgFile * img)
{
	//��imgfile�е���������dataMat
	img->dataMat = cvCreateMat(img->colCount*img->rowCount,HIST_LEN, CV_32FC1);
	img->markMat = cvCreateMat(img->colCount*img->rowCount, 1, CV_32SC1);
	

	//��������Ϣд��datamat������ڱ�Ե���Ѿ�ɾȥ��ֱ��Ϊ��ֵ
	for (int i = 0; i < img->rowCount; i++)
	{
		for (int j = 0; j < img->colCount; j++)
		{

			if (img->whiteCol[i][j] == 1)
			{
				for (int k = 0; k < HIST_LEN; k++)
				{
					cvmSet(img->dataMat, i*img->colCount + j, k, img->hists[i][j][k]);
				}
			}
			else
			{
				for (int k = 0; k < HIST_LEN; k++)
				{
					cvmSet(img->dataMat, i*img->colCount + j, k, -3.0/HIST_LEN);
				}
			}
		}
	}

	cvKMeans2(img->dataMat, CLASS_NUM, img->markMat, cvTermCriteria(CV_TERMCRIT_EPS + CV_TERMCRIT_ITER, 100000, 0.00001));

}
